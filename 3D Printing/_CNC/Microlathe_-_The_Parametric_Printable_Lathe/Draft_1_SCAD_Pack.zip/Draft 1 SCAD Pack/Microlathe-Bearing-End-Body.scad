// ===== Microlathe - Bearing End Body =====
// Cathal Garvey (cathalgarvey@gmail.com
// Creative Commons NonCommercial Sharealike Attribution license
// http://creativecommons.org/licenses/by-nc-sa/3.0/

// == Global Parameters ==
<Microlathe_Global_Params.scad>
// Imported Parameters:
// PlateRadius, EndToEndLength,
// MinSupportThickness, MedSupportThickness, MaxSupportThickness
// BearingOuterR, BearingInnerR, BearingDepth
// ChuckFittingRadius
// BoltThreadRad, BoltHeadRad, BoltHeadThickness, BoltLength, NutWidth, NutDepth
// RodThreadRad, RodNutWidth, RodNutDepth

// == Local Parameters ==
$fn=20;
PlateSpinClearance = 8;
OuterWallThickness = 2;
OuterWallDepth = 5+BearingOuterR;
HousingHalfWidth = PlateRadius + PlateSpinClearance;
OuterWallInnerRad = HousingHalfWidth-OuterWallThickness;
BackPlateThickness = 1.5;
BaseWidth = 40;
BaseLength = EndToEndLength/2;
BaseHeight = 10;

// == Modules ==
<teardrop2.scad>
module BackPlatePlusBearingHousing(){
	difference(){
	union(){
		cylinder(BackPlateThickness,HousingHalfWidth,HousingHalfWidth);
	//	translate([-HousingHalfWidth/2,0,BackPlateThickness/2]) 
	//		cube([HousingHalfWidth, HousingHalfWidth*2, BackPlateThickness],center=true);
		difference(){
			translate([0,0,BackPlateThickness])
				cylinder(BearingDepth,BearingOuterR+2,BearingOuterR+2);
			translate([0,0,BackPlateThickness])
				cylinder(BearingDepth,BearingOuterR,BearingOuterR);
		}
		difference(){
			translate([0,0,BackPlateThickness])
				cylinder(OuterWallDepth,HousingHalfWidth,HousingHalfWidth);
			translate([0,0,BackPlateThickness])
				cylinder(OuterWallDepth,OuterWallInnerRad,OuterWallInnerRad);
		}
	}
	cylinder(BackPlateThickness,BearingInnerR+1.8,BearingInnerR+1.8);
	}
}

module SpringHook(Dist,Rot,HookDepth){
	rotate([0,0,Rot]) translate([Dist,-1.5,0])
		difference(){
			cube([4,3,HookDepth*2]);
			cube([1.2,3,HookDepth]);
		}
}

module BoltSpar(Dist,Rot,Length){
	rotate([0,0,Rot])
		difference(){
			union(){
				translate([Dist,0,0])
					// The Uber Long Spars;
					cylinder(Length,BoltThreadRad+4.5,BoltThreadRad+3);
					// The Flare atop the spars: 
				translate([Dist,0,Length-BoltThreadRad*40])
					cylinder(BoltThreadRad*40,BoltThreadRad,BoltThreadRad*5);
			}
				// Sanity Cutout; Leaves the inner spin chamber unobstructed:
				cylinder(Length,OuterWallInnerRad,OuterWallInnerRad);

				// Cutout interior to Bolt-Head size, tapering up to Bolt thread.
				translate([Dist+BoltThreadRad+1.7,0,Length-16])
					cylinder(12,BoltHeadRad+0.1,BoltHeadRad+0.1);
				translate([Dist+BoltThreadRad+1.7,0,Length-4])
					cylinder(4,BoltHeadRad,BoltThreadRad);
				
				// Cutout Slit for entry of Bolt Thread:
				translate([Dist+BoltThreadRad*3.5,0,Length-4])
					cube([BoltThreadRad*3,BoltThreadRad*2,8],center=true);
				// Provide Tapering to allow Printing:
				translate([Dist+BoltThreadRad*3,0,Length-6.3])
					cylinder(6,BoltHeadRad+0.2,BoltThreadRad);
				translate([Dist+BoltThreadRad*3.5,0,Length-6.3])
					cylinder(6,BoltHeadRad+0.2,BoltThreadRad);
				translate([Dist+BoltThreadRad*4,0,Length-6.3])
					cylinder(6,BoltHeadRad+0.2,BoltThreadRad);
				translate([Dist+BoltThreadRad*3.5,0,Length-10.52])
					cube([BoltThreadRad*3, BoltHeadRad*2, 10.5],center=true);
		}
}

module HousingPlusBoltSpars(){
	union(){
		BackPlatePlusBearingHousing();
		BoltSpar(HousingHalfWidth+2,0,70);
		BoltSpar(HousingHalfWidth+2,-120,70);
		BoltSpar(HousingHalfWidth+2,120,70);
	}
}

module HousingPlusSpringHooks(){
	union(){
		BackPlatePlusBearingHousing();
		SpringHook(HousingHalfWidth-0.1,0,7);
		SpringHook(HousingHalfWidth-0.1,-120,7);
		SpringHook(HousingHalfWidth-0.1,120,7);
	}
}

module HousingFootprint(Width,Length,Height){
	difference(){
		translate([-HousingHalfWidth,0,Length/2])
			cube([Height,Width,Length],center=true);

		// Bolt-Holes:
		translate([-HousingHalfWidth,-2*Width/6,Length-6])
			cylinder(6,BoltHeadRad+0.2,BoltThreadRad);
		translate([-HousingHalfWidth,-2*Width/6,0])
			cylinder(Length-6,BoltHeadRad+0.2,BoltHeadRad+0.2);
		translate([-HousingHalfWidth,2*Width/6,Length-6])
			cylinder(6,BoltHeadRad+0.2,BoltThreadRad);
		translate([-HousingHalfWidth,2*Width/6,0])
			cylinder(Length-6,BoltHeadRad+0.2,BoltHeadRad+0.2);

		// Slide Cutout for Allen Key;
		translate([-HousingHalfWidth-4,-2*Width/6,(Length-4.5)/2])		
			cube([4,BoltThreadRad*2,Length-4.5],center=true);
		translate([-HousingHalfWidth-4,2*Width/6,(Length-4.5)/2])		
			cube([4,BoltThreadRad*2,Length-4.5],center=true);

		// Sanity Check Subtraction: Keep Spinning Area Clear:
		cylinder(Length,OuterWallInnerRad,OuterWallInnerRad);
	}
}

union(){
	HousingPlusSpringHooks();
	HousingFootprint(BaseWidth,BaseLength,BaseHeight);
}
