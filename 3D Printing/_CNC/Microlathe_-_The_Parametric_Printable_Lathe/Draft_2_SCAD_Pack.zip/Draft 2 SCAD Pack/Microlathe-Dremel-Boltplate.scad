// ===== Microlathe - Dremel End Boltplate =====
// Cathal Garvey (cathalgarvey@gmail.com
// Creative Commons NonCommercial Sharealike Attribution license
// http://creativecommons.org/licenses/by-nc-sa/3.0/

// == Global Parameters ==
<Microlathe_Global_Params.scad>
// Imported Parameters:
// PlateRadius,
// MinSupportThickness, MedSupportThickness, MaxSupportThickness
// BearingOuterR, BearingInnerR, BearingDepth
// ChuckFittingRadius
// BoltThreadR, BoltHeadR, BoltLength, BoltHeadThickness NutWidth, NutDepth
// RodThreadRad, RodNutWidth, RodNutDepth
// == Local Parameters ==
$fn= 20;
PlateThickness = 2;
DremelToolFitRadius = 2.52;
DremelToolScrewRad = 1;
RimHeight = 8;
InnerPlateBore = PlateRadius-NutDepth-MedSupportThickness;
PlateRimThickness = PlateRadius - InnerPlateBore;

// == Modules ==
<teardrop2.scad>
// teardrop(radius,height,truncated); <-- Truncated is either "true" or "false", not 1/0!

module DremelPlate(){
	cylinder(PlateThickness,PlateRadius,PlateRadius);
}

module BoltAndCapNut(rot){
	rotate([0,0,rot]) union(){
		translate([0,PlateRadius+2,RimHeight/2]) rotate([90,90,0])
			teardrop(BoltThreadRad,PlateRimThickness+4,false);
		translate([0,InnerPlateBore+PlateRimThickness/2,3*RimHeight/4])
			cube([NutWidth,NutDepth,RimHeight+4],center=true);
	}
}

module SmarterBoltRing(){
	difference(){
		cylinder(RimHeight,PlateRadius,PlateRadius);
		cylinder(RimHeight,InnerPlateBore,InnerPlateBore);
		BoltAndCapNut(0);
		BoltAndCapNut(120);
		BoltAndCapNut(240);
	}
}

module DremelBoltplate(){
union(){
		DremelPlate();
		translate([0,0,PlateThickness-0.1]) SmarterBoltRing();
	}
}

module RenderDremelBoltplate(){
translate([0,0,PlateRadius]) rotate([0,-90,0]) DremelBoltplate();
}