// ===== Microlathe - Bearing Fitting =====
// Cathal Garvey (cathalgarvey@gmail.com
// Creative Commons NonCommercial Sharealike Attribution license
// http://creativecommons.org/licenses/by-nc-sa/3.0/

// == Global Parameters ==
<Microlathe_Global_Params.scad>
// Imported Parameters:
// PlateRadius,
// MinSupportThickness, MedSupportThickness, MaxSupportThickness
// BearingOuterR, BearingInnerR, BearingDepth
// ChuckFittingRadius, DremelToolRad
// BoltThreadRad, BoltHeadRad, BoltHeadThickness, BoltLength, NutWidth, NutDepth
// RodThreadRad, RodNutWidth, RodNutDepth

// == Local Parameters ==
$fn = 20;
BearingSpurLength = 30;
PlateMinThickness = 2;
PlateThickness = NutDepth + PlateMinThickness -0.5;

// == Modules ==
<shapes.scad>
// hexagon(height,depth); <-- "Height" is actually desired cross-face-width! Depth = Height!

module BasePlateBoltHole(RadialDist,Rot){
	rotate([0,0,Rot]) translate([0,RadialDist,0]) 
		cylinder(PlateThickness,BoltThreadRad,BoltThreadRad);
	rotate([0,0,Rot]) translate([0,RadialDist,PlateMinThickness+NutDepth/2]) rotate([0,0,30])
		hexagon(NutWidth,NutDepth);
}

module FittingLeg(Width,RadialLength,Depth,Rot){
	rotate([0,0,Rot]) translate([0,2+RadialLength/2,Depth/2])
		cube([Width,RadialLength,Depth],center=true);
}

module FittingBase(){
	union(){
		cylinder(BearingSpurLength,BearingInnerR,BearingInnerR);
		FittingLeg(3+NutWidth,3+PlateRadius/2,PlateThickness,0);
		FittingLeg(3+NutWidth,3+PlateRadius/2,PlateThickness,120);
		FittingLeg(3+NutWidth,3+PlateRadius/2,PlateThickness,240);	
	}
}

module BearingFitting(){
	difference(){
		FittingBase();	
		BasePlateBoltHole(PlateRadius/2,0);
		BasePlateBoltHole(PlateRadius/2,120);
		BasePlateBoltHole(PlateRadius/2,240);
		// Bore for Dremel Disc Holder:
		cylinder(4,1,1);
		translate([0,0,1])
			cylinder(BearingSpurLength,DremelToolRad,DremelToolRad);
	}
}

module RenderBearingFitting(){
translate([0,0,PlateRadius]) rotate([0,-90,0]) BearingFitting();
}

BearingFitting();