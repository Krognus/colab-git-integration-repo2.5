// ===== Microlathe - Bearing Boltplate =====
// Cathal Garvey (cathalgarvey@gmail.com
// Creative Commons NonCommercial Sharealike Attribution license
// http://creativecommons.org/licenses/by-nc-sa/3.0/

// == Global Parameters ==
<Microlathe_Global_Params.scad>
// Imported Parameters:
// PlateRadius,
// MinSupportThickness, MedSupportThickness, MaxSupportThickness
// BearingOuterR, BearingInnerR, BearingDepth
// ChuckFittingRadius
// BoltThreadRad, BoltHeadRad, BoltLength, BoltHeadThickness, NutWidth, NutDepth
// RodThreadRad, RodNutWidth, RodNutDepth
// == Local Parameters ==
$fn= 20;
PlateThickness = 4.5;
RimHeight = 8;
InnerPlateBore = PlateRadius-NutDepth-BoltHeadThickness-MedSupportThickness;
PlateRimThickness = PlateRadius - InnerPlateBore;

// == Modules ==
<teardrop2.scad>
// teardrop(radius,height,truncated); <-- Truncated is either "true" or "false", not 1/0!

module tapertube(Length,LowerRad,UpperRad,Thickness){
	difference(){
		cylinder(Length,LowerRad,UpperRad);
		cylinder(Length,LowerRad-Thickness,UpperRad-Thickness);
	}
}

module BoltAndCapNut(rot){
	rotate([0,0,rot]) union(){
		translate([0,PlateRadius+2,RimHeight/2]) rotate([90,90,0])
			teardrop(BoltThreadRad,PlateRimThickness+4,false);
		translate([0,InnerPlateBore+2,3*RimHeight/4])
			cube([NutWidth,NutDepth,RimHeight+4],center=true);
		translate([0,PlateRadius,RimHeight]) rotate([90,90,0])
			teardrop(BoltHeadRad,2,true);
	}
}

module BasePlateBoltHole(RadialDist,Rot){
	rotate([0,0,Rot]) translate([0,RadialDist,0]) 
		cylinder(PlateThickness,BoltThreadRad,BoltThreadRad);
	rotate([0,0,Rot]) translate([0,RadialDist,PlateThickness-BoltHeadThickness])
		cylinder(BoltHeadThickness,BoltHeadRad,BoltHeadRad);
}

module Plate(){
	difference(){
		union(){
			cylinder(PlateThickness,PlateRadius,PlateRadius);
			tapertube(PlateThickness,PlateRadius/2.5,PlateRadius/2);
		}
		// Minus some radially displaced bolt-holes to attach a bearing-fitting:
		BasePlateBoltHole(PlateRadius/2,0);
		BasePlateBoltHole(PlateRadius/2,120);
		BasePlateBoltHole(PlateRadius/2,240);

		// Minus a small hole so this can be used for the Dremel end optionally:
		cylinder(PlateThickness,1,1);
	}
}

module SmarterBoltRing(){
	difference(){
		cylinder(RimHeight,PlateRadius,PlateRadius);
		cylinder(RimHeight,InnerPlateBore,InnerPlateBore);
		BoltAndCapNut(0);
		BoltAndCapNut(120);
		BoltAndCapNut(240);
	}
}

module BearingBoltplate(){
	union(){
		Plate();
		translate([0,0,PlateThickness-0.1]) SmarterBoltRing();
	}
}

module RenderBearingBoltplate(){
	translate([0,0,PlateRadius]) rotate([0,-90,0]) BearingBoltplate();
}

BearingBoltplate();