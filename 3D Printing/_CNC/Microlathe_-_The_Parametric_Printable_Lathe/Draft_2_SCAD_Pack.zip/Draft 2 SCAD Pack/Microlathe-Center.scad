// ===== Microlathe - Hex Tool Holder =====
// Cathal Garvey (cathalgarvey@gmail.com
// Creative Commons NonCommercial Sharealike Attribution license
// http://creativecommons.org/licenses/by-nc-sa/3.0/

// == Global Parameters ==
<Microlathe_Global_Params.scad>
// Imported Parameters:
// PlateRadius,
// MinSupportThickness, MedSupportThickness, MaxSupportThickness
// BearingOuterR, BearingInnerR, BearingDepth
// ChuckFittingRadius
// BoltThreadRad, BoltHeadRad, BoltLength, BoltHeadThickness, NutWidth, NutDepth
// RodThreadRad, RodNutWidth, RodNutDepth
// == Local Parameters ==
$fn= 20;
PlateThickness = 4.5;
ToolHolderRadius = 17;

CenterHeight = 13;
CenterBaseRad = 8;
Dremelable = true;

CenterRaised = true;
RaisedElevation = 8;
RaisedBaseRad = 6;

// == Modules ==
<shapes.scad>
<teardrop2.scad>
// teardrop(radius,height,truncated); <-- Truncated is either "true" or "false", not 1/0!


module CenterSpike(){
	if(CenterRaised==true){
		union(){
			translate([0,0,PlateThickness-0.1])
				cylinder(RaisedElevation,RaisedBaseRad,CenterBaseRad);
			difference(){
				translate([0,0,PlateThickness+RaisedElevation-0.1])
					cylinder(CenterHeight,CenterBaseRad,0);

				if(Dremelable==true){
					translate([0,0,PlateThickness-0.1])
						cylinder(CenterHeight+RaisedElevation,1.1,1.1);
				}
			}
		}
	}

	if(CenterRaised==false){
		difference(){
			translate([0,0,PlateThickness-0.1])
				cylinder(CenterHeight,CenterBaseRad,0);

			if(Dremelable==true){
				translate([0,0,PlateThickness-0.1])
					cylinder(CenterHeight,1.1,1.1);
			}
		}
	}
}

module BasePlateBoltHole(RadialDist,Rot){
	rotate([0,0,Rot]) translate([0,RadialDist,0]) 
		cylinder(PlateThickness,BoltThreadRad,BoltThreadRad);
	rotate([0,0,Rot]) translate([0,RadialDist,PlateThickness-BoltHeadThickness])
		cylinder(BoltHeadThickness,BoltHeadRad,BoltHeadRad);
}

module Plate(){
	difference(){
		union(){
			cylinder(PlateThickness,ToolHolderRadius,ToolHolderRadius);
		}
		// Minus some radially displaced bolt-holes to attach a bearing-fitting:
		BasePlateBoltHole(PlateRadius/2,0);
		BasePlateBoltHole(PlateRadius/2,120);
		BasePlateBoltHole(PlateRadius/2,240);

		// Minus a small hole so this can be used for the Dremel end optionally:
		cylinder(PlateThickness+2,1,1);
	}
}

module Center(){
	union(){
		Plate();
		CenterSpike();
	}
}

module RenderCenter(){
	translate([0,0,PlateRadius]) rotate([0,-90,0]) Center();
}

Center();