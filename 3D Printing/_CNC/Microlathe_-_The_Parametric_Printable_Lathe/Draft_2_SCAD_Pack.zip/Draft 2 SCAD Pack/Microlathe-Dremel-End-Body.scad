// ===== Microlathe - Bearing End Body =====
// Cathal Garvey (cathalgarvey@gmail.com
// Creative Commons NonCommercial Sharealike Attribution license
// http://creativecommons.org/licenses/by-nc-sa/3.0/

// == Global Parameters ==
<Microlathe_Global_Params.scad>
// Imported Parameters:
// PlateRadius, EndToEndLength, RotorElevation
// MinSupportThickness, MedSupportThickness, MaxSupportThickness
// BearingOuterR, BearingInnerR, BearingDepth
// ChuckFittingRadius
// BoltThreadRad, BoltHeadRad, BoltHeadThickness, BoltLength, NutWidth, NutDepth
// RodThreadRad, RodNutWidth, RodNutDepth

// == Local Parameters ==
$fn=20;
ChuckDepth = 10;
PlateSpinClearance = 12;
OuterWallThickness = 2.5;
OuterWallDepth = 8; //It's not really for safety, rather for support and rigidity.
HousingHalfWidth = PlateRadius + PlateSpinClearance;
OuterWallInnerRad = HousingHalfWidth-OuterWallThickness;
BackPlateThickness = 3;
BaseWidth = 64;
// BaseLength = EndToEndLength/2;
BaseLength = 20;
BaseHeight = 23.9;
BaseBoltOffset = 8;
BaseBoltHeight = 7;
HousingOffset = RotorElevation - HousingHalfWidth;

// == Modules ==
<teardrop2.scad>

module ChuckBracketSupport(thick,rot){
	rotate([0,0,rot])
		translate([-HousingHalfWidth/2.1,0,(BaseLength/1.5)/2])
		//	cube([HousingHalfWidth-0.8,thick,BearingDepth+BackPlateThickness],center=true);
			cube([HousingHalfWidth-0.8,thick,BaseLength/1.51],center=true);
}

module SupportedChuckHousing(){
	difference(){
	union(){
		// The Bearing-containing inner Ring:
		difference(){
			union(){
				cylinder(BackPlateThickness+ChuckDepth,ChuckFittingRadius+MedSupportThickness,ChuckFittingRadius+MedSupportThickness);
				ChuckBracketSupport(MedSupportThickness,0);
				ChuckBracketSupport(MedSupportThickness,72);
				ChuckBracketSupport(MedSupportThickness,-72);
				ChuckBracketSupport(MedSupportThickness,36);
				ChuckBracketSupport(MedSupportThickness,-36);					
			}
			translate([0,0,BackPlateThickness])
				cylinder(ChuckDepth,ChuckFittingRadius,ChuckFittingRadius);
		}
	} //Closes first "Union" of the Module	
	
	// Cut a hole for the axle to go through the bearing,
	//  plus some clearance to avoid moving parts in the bearing itself:
	cylinder(BackPlateThickness,ChuckFittingRadius,ChuckFittingRadius);

	// Trim back the BearingBracketSupports with a tidy tapering cylinder:
	translate([0,0,ChuckDepth+BackPlateThickness])
		cylinder(BaseLength/1.5-(ChuckDepth+BackPlateThickness),ChuckFittingRadius,HousingHalfWidth);

	} //Closes first "Difference" from the start of the module
}

module BoltHole(dep){
	union(){
		cylinder(MinSupportThickness,BoltThreadRad,BoltThreadRad);
		translate([0,0,MinSupportThickness-0.1])
			cylinder(dep-MinSupportThickness,BoltHeadRad,BoltHeadRad);
	}
}

module TDBoltHole(dep){
	union(){
	teardrop(BoltThreadRad,MinSupportThickness,true);
	translate([0,0,MinSupportThickness-0.1]) teardrop(BoltHeadRad,dep-MinSupportThickness,true);
	}
}

module HousingFootprint(Width,Length,Height){
	difference(){
		union(){
			translate([-HousingHalfWidth,-Width/2,0])
				cube([Height,Width,Length/1.5]);
			translate([-HousingHalfWidth,-(Width+BaseBoltOffset*2)/2,0])
				cube([BaseBoltHeight,Width+BaseBoltOffset*2,Length]);
		}
		
		// Teardrop Boltholes for bolting down the base:
		translate([-HousingHalfWidth-1,-BaseBoltOffset+(BaseBoltOffset-Width)/2,Length/4])
			rotate([0,90,0]) TDBoltHole(BaseBoltHeight+2);
		translate([-HousingHalfWidth-1,+BaseBoltOffset-(BaseBoltOffset-Width)/2,Length/4])
			rotate([0,90,0]) TDBoltHole(BaseBoltHeight+2);
		translate([-HousingHalfWidth-1,-BaseBoltOffset+(BaseBoltOffset-Width)/2,3*Length/4])
			rotate([0,90,0]) TDBoltHole(BaseBoltHeight+2);
		translate([-HousingHalfWidth-1,+BaseBoltOffset-(BaseBoltOffset-Width)/2,3*Length/4])
			rotate([0,90,0]) TDBoltHole(BaseBoltHeight+2);

		//Cylindrical boltholes to permit back-to-back additions and mods:
		translate([-2*HousingHalfWidth/3,-7*Width/16,0])
			BoltHole(Length/1.4);
		translate([-2*HousingHalfWidth/3,7*Width/16,0])
			BoltHole(Length/1.4);

		// Sanity Check Subtraction: Keep Spinning Area Clear:
		cylinder(Length,OuterWallInnerRad,OuterWallInnerRad);
	}
}

// === Construction ===
module DremelEndBody(){
	translate([HousingHalfWidth/2,0,0])
	union(){
		SupportedChuckHousing();
		HousingFootprint(BaseWidth,BaseLength,BaseHeight);
	}
}

module RenderDremelEndBody(){
translate([0,0,HousingHalfWidth/2]) rotate([0,-90,0]) DremelEndBody();
}