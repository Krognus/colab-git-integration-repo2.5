// ===== Microlathe - Global Parameters =====
// Cathal Garvey (cathalgarvey@gmail.com
// Creative Commons NonCommercial Sharealike Attribution license
// http://creativecommons.org/licenses/by-nc-sa/3.0/

// All dimensions in Millimeters.
// == Device Params ==
// PlateRadius is the radius of the spinning plates that grip things
// EndToEndLength is the total length of the Lathe. It was only used
//   to generate the Base Length on the body sections. Planning to
//   deprecate that design in favour of a bolted-down version instead.
// RotorElevation is how high the Rotor is from the ground.
//   It's used to generate body sections properly.
//   OFC, it must be larger than PlateRadius.
PlateRadius = 20;
EndToEndLength = 150;
RotorElevation = 30; //The original would have had the equivalent of 25..

// == Plastic Tolerance Parameters ==
// MinSupportThickness is how thick the plastic should be at minimum
//   if it is expected to bear a light load.
// MedSupportThickness is how thick the plastic should be when it is
//   expected to support a medium load.
// MaxSupportThickness is how thick the plastic should be when it is
//   expected to support a large load.
MinSupportThickness = 1.5;
MedSupportThickness = 3;
MaxSupportThickness = 6;

// == 608 Bearing Parameters ==
// Bearing OuterR/InnerR are simply the outer radius and inner radius.
// BearingDepth is the distance from face to face of a bearing.
BearingOuterR = 11;
BearingInnerR = 4.56; //Better to be too large than too small; shave down if needed?
BearingDepth = 7;

// == Drill Parameters ==
// Chuck Fitting Radius: As in, how wide is whatever bit is immediately
//   before the chuck that can be built around?
// ChuckFittingOffset is how far back from the start of the chuck the
//   chuck fitting is.
// DremelGroundClearance is how high the lowest support for the dremel
//   body needs to be: It is the "Radius" of the thickest portion of the tool.
// DremelGroundClearanceOffset is how far from the Dremel chuck this is.
// DremelToolLength is how far from the chuck the disc-holder protudes.
ChuckFittingRadius = 9.3;
ChuckFittingOffset = 23;
DremelGroundClearance = 24;
DremelGroundClearanceOffset = 75;
DremelToolLength = 18;
DremelToolRad = 2.7;

// == Bolt/Nut Parameters ==
// Assumes Bolt+Hex Nut
// NutWidth is the width across a nut from one of the six faces to the
//   opposing face.
// NutDepth is how thick the nut is from one end of the threaded hole
//   to the other.
BoltThreadRad = 1.5;
BoltHeadRad = 2.8;
BoltHeadThickness = 3;
BoltLength = 15;
NutWidth = 5.7;
NutDepth = 2.5;

// == Threaded Rod/Nut Parameters ==
// Assumes lengths of threaded rod used to connect ends, with large
//   hex nuts.
RodThreadRad = 6.5;
RodNutWidth = 13;
RodNutDepth = 6; //Check later!
