// ===== Microlathe - Render Preview =====
// Cathal Garvey (cathalgarvey@gmail.com, @onetruecathal)
// Creative Commons NonCommercial Sharealike Attribution license
// http://creativecommons.org/licenses/by-nc-sa/3.0/

<Microlathe-Bearing-Boltplate.scad>
<Microlathe-Bearing-End-Body.scad>
<Microlathe-Bearing-Fitting.scad>
<Microlathe-Dremel-Boltplate.scad>
<Microlathe-Dremel-End-Body.scad>

// === Imported Rendering Modules ===
// RenderBearingEndBody(),
// RenderDremelEndBody(),
// RenderBearingFitting(),
// RenderDremelBoltplate(),
// RenderBearingBoltplate(),

// === Setup Construction ===
translate([50,0,0]) RenderBearingEndBody();
rotate([0,0,180]) translate([50,0,0]) RenderDremelEndBody();
rotate([0,0,180]) translate([35,0,12]) RenderDremelBoltplate();
translate([35,0,12]) RenderBearingBoltplate();
rotate([0,0,180]) translate([-36,0,12]) RenderBearingFitting();