// ===== Microlathe - Hex Tool Holder =====
// Cathal Garvey (cathalgarvey@gmail.com
// Creative Commons NonCommercial Sharealike Attribution license
// http://creativecommons.org/licenses/by-nc-sa/3.0/

// == Global Parameters ==
<Microlathe_Global_Params.scad>
// Imported Parameters:
// PlateRadius,
// MinSupportThickness, MedSupportThickness, MaxSupportThickness
// BearingOuterR, BearingInnerR, BearingDepth
// ChuckFittingRadius
// BoltThreadRad, BoltHeadRad, BoltLength, BoltHeadThickness, NutWidth, NutDepth
// RodThreadRad, RodNutWidth, RodNutDepth
// == Local Parameters ==
$fn= 20;
PlateThickness = 4.5;
CubbyHeight = 12.5;
ToolHolderRadius = 17;
HexToolWidth = 6.85;

// == Modules ==
<shapes.scad>
<teardrop2.scad>
// teardrop(radius,height,truncated); <-- Truncated is either "true" or "false", not 1/0!

module BasePlateBoltHole(RadialDist,Rot){
	rotate([0,0,Rot]) translate([0,RadialDist,0]) 
		cylinder(PlateThickness,BoltThreadRad,BoltThreadRad);
	rotate([0,0,Rot]) translate([0,RadialDist,PlateThickness-BoltHeadThickness])
		cylinder(BoltHeadThickness,BoltHeadRad,BoltHeadRad);
}

module Plate(){
	difference(){
		union(){
			cylinder(PlateThickness,ToolHolderRadius,ToolHolderRadius);
		}
		// Minus some radially displaced bolt-holes to attach a bearing-fitting:
		BasePlateBoltHole(PlateRadius/2,0);
		BasePlateBoltHole(PlateRadius/2,120);
		BasePlateBoltHole(PlateRadius/2,240);

		// Minus a small hole so this can be used for the Dremel end optionally:
		cylinder(PlateThickness,1,1);
	}
}

module HexToolCubby(){
	difference(){
		translate([0,0,CubbyHeight/2+PlateThickness-0.1])
			hexagon(HexToolWidth+MedSupportThickness*2,CubbyHeight);
		translate([0,0,CubbyHeight/2+PlateThickness-0.1])
			hexagon(HexToolWidth,CubbyHeight);	
	}
}

module HexToolHolder(){
	union(){
		Plate();
		HexToolCubby();
	}
}

module RenderHexToolHolder(){
	translate([0,0,PlateRadius]) rotate([0,-90,0]) HexToolHolder();
}

HexToolHolder();