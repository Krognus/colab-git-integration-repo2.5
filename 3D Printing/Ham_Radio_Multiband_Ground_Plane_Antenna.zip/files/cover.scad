
translate ([0,50,-1])
cylinder (h=4, d=15, $fn=30);      
 translate ([0,50,thickness])
 cube ([26.5, 26.5, 2], center=true);
        //holes



