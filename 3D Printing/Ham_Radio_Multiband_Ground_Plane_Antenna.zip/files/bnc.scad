

 difference(){      
 translate ([0,50,-1])
    cube ([26.5, 26.5, 3], center=true);
#translate ([0,50,-5]) cylinder (h=30, d=9.4, $fn=30);
translate ([0,50,-1]) cylinder (h=30, d=12.6, $fn=30);
 
    
        //holes
translate ([9,41,-5])
cylinder (h=30, d=3.2, $fn=30); 
translate ([-9,41,-5])
cylinder (h=30, d=3.2, $fn=30);
translate ([9,59,-5])
cylinder (h=30, d=3.2, $fn=30); 
  translate ([-9,59,-5])
cylinder (h=30, d=3.2, $fn=30);  
 }
