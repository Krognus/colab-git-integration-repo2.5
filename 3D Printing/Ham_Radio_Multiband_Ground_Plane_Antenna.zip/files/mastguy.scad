$fn=100;
mast=5;
hole=5;

module rcylinder(r1=10,r2=10,h=10,b=2)
{translate([0,0,-h/2]) hull(){rotate_extrude() translate([r1-b,b,0]) circle(r = b); rotate_extrude() translate([r2-b, h-b, 0]) circle(r = b);}}

difference(){
union(){
rcylinder(r1=mast+10,r2=mast+10,h=3,b=1);
 translate([mast+10,0,0])rcylinder(r1=hole*2,r2=10,h=3,b=1);
 translate([-mast-10,0,0])rcylinder(r1=hole*2,r2=10,h=3,b=1);
    translate([0,mast+10,0])rcylinder(r1=hole*2,r2=10,h=3,b=1);
    translate([0,-mast-10,0])rcylinder(r1=hole*2,r2=10,h=3,b=1);
}
// hole for mast
translate([0,0,-5])cylinder(d=mast,h=10);
//hole for gying lines
translate([mast+10,0,-5])cylinder(d=hole,h=10);
translate([-mast-10,0,-5])cylinder(d=hole,h=10);
translate([0,mast+10,-5])cylinder(d=hole,h=10);
translate([0,-mast-10,-5])cylinder(d=hole,h=10);

//hole for vertical element
translate([mast/2+3,0,-5])cylinder(d=3,h=10);
}