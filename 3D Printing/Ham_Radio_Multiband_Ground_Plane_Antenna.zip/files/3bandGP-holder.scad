$fs = 0.15;
$fn=50;
holder_bottom=1;
holder_top=0;
module roundedcube(size = [1, 1, 1], center = false, radius = 0.5, apply_to = "all") {
	// If single value, convert to [x, y, z] vector
	size = (size[0] == undef) ? [size, size, size] : size;

	translate_min = radius;
	translate_xmax = size[0] - radius;
	translate_ymax = size[1] - radius;
	translate_zmax = size[2] - radius;

	diameter = radius * 2;

	obj_translate = (center == false) ?
		[0, 0, 0] : [
			-(size[0] / 2),
			-(size[1] / 2),
			-(size[2] / 2)
		];

	translate(v = obj_translate) {
		hull() {
			for (translate_x = [translate_min, translate_xmax]) {
				x_at = (translate_x == translate_min) ? "min" : "max";
				for (translate_y = [translate_min, translate_ymax]) {
					y_at = (translate_y == translate_min) ? "min" : "max";
					for (translate_z = [translate_min, translate_zmax]) {
						z_at = (translate_z == translate_min) ? "min" : "max";

						translate(v = [translate_x, translate_y, translate_z])
						if (
							(apply_to == "all") ||
							(apply_to == "xmin" && x_at == "min") || (apply_to == "xmax" && x_at == "max") ||
							(apply_to == "ymin" && y_at == "min") || (apply_to == "ymax" && y_at == "max") ||
							(apply_to == "zmin" && z_at == "min") || (apply_to == "zmax" && z_at == "max")
						) {
							sphere(r = radius);
						} else {
							rotate = 
								(apply_to == "xmin" || apply_to == "xmax" || apply_to == "x") ? [0, 90, 0] : (
								(apply_to == "ymin" || apply_to == "ymax" || apply_to == "y") ? [90, 90, 0] :
								[0, 0, 0]
							);
							rotate(a = rotate)
							cylinder(h = diameter, r = radius, center = true);
						}
					}
				}
			}
		}
	}
}

module dipole()
{   
    difference() {
    union(){       
    translate([0,13,0])
    roundedcube([40,28,15],true,5,"x");    
   //cylinder(h = 15, d=30, center = true);
    if(holder_bottom==0)
    translate([0,17,10])    
    roundedcube([30,20,25],true,5,"x");
    #rotate([90,0,0])
    translate([0,0,-15])
    cylinder(h = 50, d=8.5, center = true); 
     // cube([30,20,30], center=true);    
    } 
    if(holder_top==0)
    rotate([0,0,90])
    translate([-20,0,0])     
    cylinder(h = 60, d=60, center = true, $fn=5);
     
    
   
    // pasek
    if(holder_top==0)
    rotate([0,0,90])
    translate([-15,-19.1,0])
    #cube([50,2,6], center=true);
    
     rotate([0,0,90])
    translate([-15,19.1,0])
    #cube([50,2,6], center=true);
    translate([0,10,0])
    #cube([50,2,6], center=true);
    
    rotate([90,0,0])
    translate([0,0,10])
    cylinder(h = 30, d=2, center = true);
    //vykusy
    if(holder_bottom==0){
    translate([0,22,0])
    cube([15,15,15], center=true);
    translate([0,22,12])
    cube([20,17,14], center=true);
    }
    //vicko
   //translate([0,26,15])
    //#cube([30,2,20], center=true);
    
    
    // translate([-6,22,0])
    //cube([7,15,15], center=true);
    if(holder_bottom==0){
    translate([0,20,20])
    cylinder(h = 35, d=9.2, center = true);
    translate([0,20,26])
    #cylinder(h = 10, d=12.6, center = true);
    }
    }
 
}
dipole();
//holder();