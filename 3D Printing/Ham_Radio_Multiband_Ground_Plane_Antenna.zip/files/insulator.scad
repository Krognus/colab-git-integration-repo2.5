//Ground plane  antenna radial end insulator.
//  ondra@ok1cdj.com

$fn=50;
band="GP";
difference(){
minkowski()
{ 
cube(size =[35,3,2], center=true);
cylinder(r=5,h=1);
}
translate([-18,0,-5])
#cylinder(d=2.5,h=20);
translate([15,0,-5])
cylinder(d=6,h=20);
translate([-10,0,-5])
cylinder(d=2.5,h=20);

}


}